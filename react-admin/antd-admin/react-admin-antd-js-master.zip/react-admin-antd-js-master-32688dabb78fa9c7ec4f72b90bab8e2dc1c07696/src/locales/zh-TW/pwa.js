export default {
  'app.pwa.offline': '當前處於離線狀態',
  'app.pwa.serviceworker.updated': '有新內容',
  'app.pwa.serviceworker.updated.hint': '請點擊“刷新”按鈕或者手動刷新頁面',
  'app.pwa.serviceworker.updated.ok': '刷新',
};
