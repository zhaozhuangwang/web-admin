//请求URL
layui.define([],function(exports){
    exports('api',{
        login:'json/login.js',
        getMenu:'json/menu.js',
        getGoods:'json/goods.js'
    });
})