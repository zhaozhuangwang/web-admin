# nepadmin 后台单页面模板
基于 layui。</br>
遵循原生 HTML/CSS/JS 的书写与组织形式，上手容易，拿来即用。</br>
最低兼容到IE8浏览器。</br>

![avatar](https://cdn.layui.com/upload/2018_9/8603952_1537076911174_42129.jpg)

### [在线预览](https://june000.gitee.io/nep-admin/)
