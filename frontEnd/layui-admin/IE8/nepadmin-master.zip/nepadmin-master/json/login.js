{
	"code": 0,
	"msg": "ok",
	"data": {
        "token":"nepadmin-token-test",
        "user":{
            "username":"小明"
        }
    }
}