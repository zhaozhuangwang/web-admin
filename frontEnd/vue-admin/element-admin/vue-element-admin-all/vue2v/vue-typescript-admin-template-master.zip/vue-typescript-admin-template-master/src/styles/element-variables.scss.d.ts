export interface IScssVariables {
  theme: string
}

export const variables: IScssVariables

export default variables
