// @ts-nocheck
import { Plugin } from '/Users/zhuangwang/Desktop/works/web/node/react/web/admins/antd-ts/node_modules/@umijs/preset-built-in/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','dva','getInitialState','initialStateConfig','locale','locale','request',],
});

export { plugin };
