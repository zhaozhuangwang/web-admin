# Gitter

[Gitter](https://gitter.im/vue-element-admin/discuss)

<script>
export default {
  mounted () {
    window.open('https://gitter.im/vue-element-admin/discuss')
  }
}
</script>
