# 更新记录

[在线查看更新记录](https://github.com/PanJiaChen/vue-element-admin/releases)

<script>
export default {
  mounted () {
    window.open('https://github.com/PanJiaChen/vue-element-admin/releases')
  }
}
</script>
