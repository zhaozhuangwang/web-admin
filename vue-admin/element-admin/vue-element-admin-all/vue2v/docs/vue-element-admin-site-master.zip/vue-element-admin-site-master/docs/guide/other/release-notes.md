# Release Notes

[Release Notes](https://github.com/PanJiaChen/vue-element-admin/releases)

<script>
export default {
  mounted () {
    window.open('https://github.com/PanJiaChen/vue-element-admin/releases')
  }
}
</script>
