---
sidebar: false
---

::: tip Donar
Si encuentras útil este proyecto, puedes comprar un vaso de jugo para el autor :tropical_drink:
:::

![donar](https://panjiachen.gitee.io/gitee-cdn/vue-element-admin-site/bd273f0d-83a0-4ef2-92e1-9ac8ed3746b9.png)

## O

[PayPal](https://www.paypal.me/panfree23)

[Compra un cafe](https://www.buymeacoffee.com/Pan)

## Apoyo mensual

Los proyectos de código abierto consumen gran parte de mi tiempo de descanso. Y al final del día, todos tenemos que poner un techo sobre nuestras cabezas y comida en la mesa, es por eso que tengo una página de patrón.

<a target="_blank" href="https://www.patreon.com/panjiachen">
<img src="https://c5.patreon.com/external/logo/become_a_patron_button@2x.png" height="50">
</a>
