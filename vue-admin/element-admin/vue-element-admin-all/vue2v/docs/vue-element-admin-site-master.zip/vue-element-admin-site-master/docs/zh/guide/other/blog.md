# 圈主 Blog

作者 [个人圈子](https://jianshiapp.com/circles/1209) 经常分享一些技术相关的东西

<script>
export default {
  mounted () {
    window.open('https://jianshiapp.com/circles/1209')
  }
}
</script>
