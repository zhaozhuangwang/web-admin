## Guía de Webpack

Recomendado [survivejs](https://survivejs.com/webpack/foreword/)

Aquí para compartir la trilogía del paquete web, básicamente lee el ingeniero de configuración de webpack en este campo.

**No hay traducción al Español**

- [Comenzando con webpack 4 y aplicaciones de página única](https://github.com/wallstreetcn/webpack-and-spa-guide)
- [Las manos tocan tu mano, te usan con una postura razonable usando webpack4 (arriba)](https://juejin.im/post/5b56909a518825195f499806)
- [Las manos tocan tu mano, te usan con una postura razonable usando webpack4 (abajo)](https://juejin.im/post/5b5d6d6f6fb9a04fea58aabc)
