---
sidebar: false
---

::: tip Donate
If you find this project useful, you can buy author a glass of juice :tropical_drink:
:::

![donate](https://panjiachen.gitee.io/gitee-cdn/vue-element-admin-site/bd273f0d-83a0-4ef2-92e1-9ac8ed3746b9.png)

## Or

[PayPal](https://www.paypal.me/panfree23)

[Buy me a coffee](https://www.buymeacoffee.com/Pan)

## Monthly support

Open source projects consume a lot of my rest time. And at the end of the day we all have to put a roof over our heads and food on the table, so this is why I have a patreon-page.

<a target="_blank" href="https://www.patreon.com/panjiachen">
<img src="https://c5.patreon.com/external/logo/become_a_patron_button@2x.png" height="50">
</a>
