# vue-element-admin-site

The documentation source of [vue-element-admin](https://github.com/PanJiaChen/vue-element-admin)

[Online](https://panjiachen.github.io/vue-element-admin-site)

[Gitee Online](https://panjiachen.gitee.io/vue-element-admin-site/zh/)

## Development

```bash
# clone the project
git clone git@github.com:PanJiaChen/vue-element-admin-site.git

# install dependency
npm install

# develop
npm run dev
```

open http://localhost:8080/vue-element-admin-site/

> Generator by [vuepress](https://github.com/vuejs/vuepress)
