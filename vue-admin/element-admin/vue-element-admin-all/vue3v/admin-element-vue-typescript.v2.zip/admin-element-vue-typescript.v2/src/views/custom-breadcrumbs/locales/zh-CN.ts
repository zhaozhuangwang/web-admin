export default {
  'page.custom-breadcrumbs.msg': '请看上方面包屑。',
};
