export interface TableListItem {
  id: number;
  title: string;
  hit: number;
}
