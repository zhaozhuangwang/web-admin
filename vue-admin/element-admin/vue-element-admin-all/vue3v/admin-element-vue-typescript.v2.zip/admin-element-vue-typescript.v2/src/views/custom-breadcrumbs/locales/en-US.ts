export default {
  'page.custom-breadcrumbs.msg': 'Look at the crumbs on the top.',
};
