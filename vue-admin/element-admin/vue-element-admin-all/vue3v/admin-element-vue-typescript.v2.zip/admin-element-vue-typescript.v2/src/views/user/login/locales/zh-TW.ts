export default {
  'page.user.login.form-item-username': '用戶名: admin or test or user',
  'page.user.login.form-item-username.required': '請輸入用戶名',
  'page.user.login.form-item-password': '密碼: 123456',
  'page.user.login.form-item-password.required': '請輸入密碼',
  'page.user.login.form.title': '賬戶登錄',
  'page.user.login.form.btn-submit': '登 錄',
  'page.user.login.form.btn-jump': '還沒有賬戶？現在註冊！',
  'page.user.login.form.login-error': '用戶名或密碼錯誤！',
  'page.user.login.form.login-success': '登錄成功！',
};
