export interface TableFormDataType {
  key: string;
  name?: string;
  workId?: string;
  edit?: boolean;
  isNew?: boolean;
}