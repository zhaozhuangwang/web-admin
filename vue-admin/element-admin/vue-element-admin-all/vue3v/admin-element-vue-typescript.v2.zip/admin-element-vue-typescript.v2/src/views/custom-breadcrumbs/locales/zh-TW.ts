export default {
  'page.custom-breadcrumbs.msg': '請看上方面包屑。',
};
