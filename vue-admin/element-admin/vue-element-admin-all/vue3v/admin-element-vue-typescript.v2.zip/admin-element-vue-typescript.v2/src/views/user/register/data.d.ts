export interface RegisterParamsType {
  username: string;
  password: string;
  confirm: string;
}
