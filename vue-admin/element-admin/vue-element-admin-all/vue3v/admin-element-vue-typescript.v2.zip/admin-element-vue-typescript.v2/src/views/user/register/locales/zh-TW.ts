export default {
  'page.user.register.form-item-username': '用戶名',
  'page.user.register.form-item-username.required': '請輸入用戶名',
  'page.user.register.form-item-password': '密碼',
  'page.user.register.form-item-password.required': '請輸入密碼',
  'page.user.register.form-item-confirmpassword': '確認密碼',
  'page.user.register.form-item-confirmpassword.compare':
    '您輸入的兩個密碼不匹配！',
  'page.user.register.form.title': '註冊賬戶',
  'page.user.register.form.btn-submit': '註 冊',
  'page.user.register.form.btn-jump': '已有賬戶？現在登錄！',
  'page.user.register.form.register-success': '註冊成功，請登錄！',
};
