export default {
  'page.icon.svg.remark.title': 'Remark：',
};
