export interface TableListItem {
  name: string;
  hit: number;
}
