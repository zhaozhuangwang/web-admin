export interface LoginParamsType {
  username: string;
  password: string;
}
