<template>
    <div class="indexlayout-main-conent">
        <el-card shadow="never" class="cus-card">
           此页面只有 test 与 admin 账号可以查看。
        </el-card>
    </div>
</template>