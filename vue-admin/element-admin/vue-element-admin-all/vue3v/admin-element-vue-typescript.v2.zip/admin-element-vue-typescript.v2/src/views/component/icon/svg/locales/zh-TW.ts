export default {
  'page.icon.svg.remark.title': '說明：',
};
