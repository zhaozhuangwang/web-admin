export interface TableListItem {
  id: number;
  name: string;
  hit: number;
  pinyin?: string;
}
