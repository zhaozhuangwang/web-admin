import IconFont from './index.vue';

export default IconFont;