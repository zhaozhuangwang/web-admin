export default {
    'empty': 'empty',
    'app.global.menu.notfound': 'Not Found',
    'app.global.form.validatefields.catch': '验证不通过，请检查输入',
};