export default {
    'empty': 'empty',
    'app.global.menu.notfound': 'Not Found',
    'app.global.form.validatefields.catch': '驗證不通過，請檢查輸入',
};