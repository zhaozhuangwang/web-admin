export default {
    'empty': 'empty',
    'app.global.menu.notfound': 'Not Found',
    'app.global.form.validatefields.catch': 'The validation did not pass, please check the input',
};