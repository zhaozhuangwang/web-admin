export default {
  'user-layout.menu.login': '登录',
  'user-layout.menu.register': '注册',
};
