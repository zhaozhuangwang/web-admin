export default {
  'user-layout.menu.login': '登錄',
  'user-layout.menu.register': '註冊',
};
