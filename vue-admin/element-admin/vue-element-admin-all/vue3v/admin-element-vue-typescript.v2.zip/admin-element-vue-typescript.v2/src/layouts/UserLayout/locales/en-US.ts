export default {
  'user-layout.menu.login': 'Login',
  'user-layout.menu.register': 'Register',
};
